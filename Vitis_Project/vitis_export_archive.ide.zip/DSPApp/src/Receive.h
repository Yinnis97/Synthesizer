// #include "arm_math.h"
// #include "arm_const_structs.h"

/*
#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "audio.h"
#include "math.h"
#include "xparameters.h"
#include "sleep.h"
#include "xiicps.h"
#include "xscutimer.h"
#include "xscugic.h"
#include "arm_math.h"

#define SAMPLE_RATE 1000  // Samples per second
#define FREQUENCY 50      // Frequency of the sine wave in Hz
#define NUM_SAMPLES 100   // Total samples

#define FFT_SIZE 100  // Must be a power of 2

float32_t input_signal[FFT_SIZE * 2]; // Complex input (real + imaginary)
float32_t output_signal[FFT_SIZE];    // FFT result
float32_t magnitude[FFT_SIZE / 2];    // FFT magnitude

arm_rfft_fast_instance_f32 fft_instance;  // FFT instance

int main() {
    arm_rfft_fast_init_f32(&fft_instance, FFT_SIZE);
    float sine_wave[NUM_SAMPLES];
    printf("Testezionfbnjn\n\r");
       for (int i = 0; i < NUM_SAMPLES; i++) {
           float t = (float)i / SAMPLE_RATE;  // Time instance
           sine_wave[i] = sin(2 * M_PI * FREQUENCY * t);
       }


       // Perform FFT
       arm_rfft_fast_f32(&fft_instance, sine_wave, output_signal, 0);

       // Compute magnitude
       arm_cmplx_mag_f32(sine_wave, magnitude, FFT_SIZE);

       // Find the index of the peak magnitude:
       float max_val = 0.0f;
       int max_index = 0;

       arm_max_f32(magnitude, FFT_SIZE, &max_val, &max_index);
       printf("Max Value %f\n\r",max_val);

       // Convert the bin index to frequency:
       //float frequency = (max_index * SAMPLE_RATE) / FFT_SIZE;
       //xil_printf("Freq = %f",frequency);

    return 0;
}
*/
