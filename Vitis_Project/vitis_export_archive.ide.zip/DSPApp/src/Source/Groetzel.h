#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "audio.h"
#include "math.h"
#include "xparameters.h"
#include "sleep.h"
#include "xiicps.h"
#include "xscutimer.h"
#include "xscugic.h"
#include "arm_math.h"

#define SAMPLE_COUNT 205  // Number of samples per Goertzel window
#define SAMPLE_RATE 48000 // 48 kHz sampling rate

int main()
{
	read_DTMF_signal();

	return 0;
}

void read_DTMF_signal() {
    int16_t samples[SAMPLE_COUNT];  // Buffer for storing PCM samples

    printf("Listening for DTMF tones...\n");

    for (int i = 0; i < SAMPLE_COUNT; i++) {
        // Read PCM audio sample from I2S receiver
        uint32_t audio_data = Xil_In32(I2S_DATA_RX_L_REG);

        // Extract 16-bit sample (audio_data is 32-bit, but we're using 16-bit PCM)
        samples[i] = (int16_t)(audio_data & 0xFFFF);

        usleep(1000000 / SAMPLE_RATE);  // Wait for the next sample
    }

    printf("Processing DTMF signal...\n");

    // Run Goertzel algorithm to detect frequencies
    detect_DTMF(samples);
}

double goertzel(int target_freq, int16_t *samples) {
    double s_prev = 0.0, s_prev2 = 0.0, s;
    double coeff = 2.0 * cos(2.0 * M_PI * target_freq / SAMPLE_RATE);

    for (int i = 0; i < SAMPLE_COUNT; i++) {
        s = samples[i] + coeff * s_prev - s_prev2;
        s_prev2 = s_prev;
        s_prev = s;
    }

    return (s_prev2 * s_prev2 + s_prev * s_prev - coeff * s_prev * s_prev2);
}


void detect_DTMF(int16_t *samples) {
    double power[8];
    int freqs[8] = {697, 770, 852, 941, 1209, 1336, 1477, 1633};

    // Run Goertzel on all DTMF frequencies
    for (int i = 0; i < 8; i++) {
        power[i] = goertzel(freqs[i], samples);
    }

    int low_freq = -1, high_freq = -1;
    double max_low = 0, max_high = 0;

    // Find dominant low and high frequencies
    for (int i = 0; i < 4; i++) {
        if (power[i] > max_low) {
            max_low = power[i];
            low_freq = freqs[i];
        }
    }

    for (int i = 4; i < 8; i++) {
        if (power[i] > max_high) {
            max_high = power[i];
            high_freq = freqs[i];
        }
    }

    printf("Detected Frequencies: %d Hz and %d Hz\n", low_freq, high_freq);

    // Match detected frequencies to a DTMF digit
    char dtmf_digit = '-';
    if (low_freq == 697 && high_freq == 1209) dtmf_digit = '1';
    else if (low_freq == 697 && high_freq == 1336) dtmf_digit = '2';
    else if (low_freq == 697 && high_freq == 1477) dtmf_digit = '3';
    else if (low_freq == 770 && high_freq == 1209) dtmf_digit = '4';
    else if (low_freq == 770 && high_freq == 1336) dtmf_digit = '5';
    else if (low_freq == 770 && high_freq == 1477) dtmf_digit = '6';
    else if (low_freq == 852 && high_freq == 1209) dtmf_digit = '7';
    else if (low_freq == 852 && high_freq == 1336) dtmf_digit = '8';
    else if (low_freq == 852 && high_freq == 1477) dtmf_digit = '9';
    else if (low_freq == 941 && high_freq == 1336) dtmf_digit = '0';
    else if (low_freq == 941 && high_freq == 1209) dtmf_digit = '*';
    else if (low_freq == 941 && high_freq == 1477) dtmf_digit = '#';
    else if (low_freq == 697 && high_freq == 1633) dtmf_digit = 'A';
    else if (low_freq == 770 && high_freq == 1633) dtmf_digit = 'B';
    else if (low_freq == 852 && high_freq == 1633) dtmf_digit = 'C';
    else if (low_freq == 941 && high_freq == 1633) dtmf_digit = 'D';

    printf("Detected DTMF Digit: %c\n", dtmf_digit);
}
